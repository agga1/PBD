

/*
OnloanView: Queries the loan, title, and member tables.
Lists the member, title, and loan information of a copy that is currently on loan.  
*/

CREATE VIEW dbo.OnloanView
AS
SELECT
	loan.isbn,
	loan.copy_no,
	loan.title_no,
	title.title,
	title.author,
	loan.member_no,
	member.lastname,
	member.firstname,
	loan.out_date,
	loan.due_date
FROM loan
JOIN title
ON title.title_no = loan.title_no
JOIN member
ON member.member_no = loan.member_no
go

