
/* 
ChildwideView: queries the member, adult, and juvenile tables.  
Lists the name & address for the juveniles.
*/

CREATE VIEW dbo.ChildwideView
AS
SELECT 
	juvenile.member_no,
	member.lastname,
	member.firstname,
	member.middleinitial,
	adult.street,
	adult.city,
	adult.state,
	adult.zip,
	adult.phone_no,
	adult.expr_date
FROM juvenile
JOIN member
ON member.member_no = juvenile.member_no
JOIN adult
ON adult.member_no = juvenile.adult_member_no
go

