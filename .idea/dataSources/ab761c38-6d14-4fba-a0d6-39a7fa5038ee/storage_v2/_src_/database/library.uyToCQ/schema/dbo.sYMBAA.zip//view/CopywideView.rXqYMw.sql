

/*
CopywideView: Queries the copy, title and item tables.  
Lists complete information about each copy.
*/

CREATE VIEW dbo.CopywideView
AS
SELECT 
	copy.isbn,
	copy.copy_no,
	title.title,
	title.author,
	item.translation,
	item.loanable,
	copy.on_loan
FROM copy
JOIN item
ON item.isbn = copy.isbn
JOIN title
ON title.title_no = copy.title_no
go

