

/*
LoanableView: Queries CopywideView (3 table join).  
Lists complete information about each copy marked as loanable.
*/

CREATE VIEW dbo.LoanableView
AS
SELECT *
FROM CopywideView
WHERE loanable = 'Y'
go

