

/*
OverdueView: Queries OnloanView. (3 table join.)
Lists the member, title, and loan information of a copy on loan that is overdue. 
*/

CREATE VIEW dbo.OverdueView
AS
SELECT *
FROM OnloanView
WHERE OnloanView.due_date < GETDATE()
go

