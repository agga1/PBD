


/*
Create views for the library database.
*/

/* 
AdultwideView: queries the member and adult tables.  
Lists the name & address for all adults. 
*/

CREATE VIEW dbo.AdultwideView
AS
SELECT	adult.member_no,
	member.lastname,
	member.firstname,
	member.middleinitial,
	adult.street,
	adult.city,
	adult.state,
	adult.zip,
	adult.phone_no,
	adult.expr_date
FROM adult
JOIN member
ON adult.member_no = member.member_no
go

