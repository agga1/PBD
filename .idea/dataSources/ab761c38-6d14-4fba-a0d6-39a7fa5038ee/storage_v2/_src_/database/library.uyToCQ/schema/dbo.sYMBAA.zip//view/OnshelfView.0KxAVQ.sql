
/* 
OnshelfView: Queries CopywideView (3 table join).
Lists complete information about each copy that is not currently on loan.
*/

CREATE VIEW dbo.OnshelfView
AS
    SELECT *
    FROM CopywideView
    WHERE on_loan ='N'
go

